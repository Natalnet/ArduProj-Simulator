configPins(){
    //Configure as estradas e saidas do componente aqui.
    return({
        connector0: 'in',
        connector1: 'out'
    })
    
}

main(input){
    
    var output = {
        ...input,
        ['connector1']: {
            value:1,
            type:''
    }}
    
    console.log('bateria')
    
    return output
}