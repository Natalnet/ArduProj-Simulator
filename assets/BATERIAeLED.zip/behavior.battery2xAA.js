configPins(){
    //Configure as estradas e saidas do componente aqui.
    return({
        connector0: 'in',
        connector1: 'out'
    })
    
}

main(input){
    
    var output = {
        ...input,
       connectors: {
            connector0pin:0,
            connector1pin:1
    }}
    
    console.log('bateria')
    
    return output
}