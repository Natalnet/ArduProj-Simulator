configPins(){
    //Configure as estradas e saidas do componente aqui.
    return({
        type:'power_source',
        pins:{
            connector76pin: 'in-out',
            connector77pin: 'in-out',
            connector78pin: 'in-out',
            connector79pin: 'in-out',
            connector80pin: 'in-out',
            connector81pin: 'in-out',
            connector82pin: 'in-out',
            connector83pin: 'in-out',
            connector84pin: 'in-out',
            connector85pin: 'in-out',
            connector86pin: 'in-out',
            connector87pin: 'in-out',
            connector88pin: 'in-out',
            connector89pin: 'in-out',
            connector90pin: 'in-out',
            connector91pin: 'in-out',
            connector92pin: 'in-out',
            connector93pin: 'in-out',
            connector94pin: 'in-out',
            connector95pin: 'in-out',
            connector96pin: 'in-out',
            connector97pin: 'in-out',
            connector98pin: 'in-out',
            connector99pin: 'in-out',
            connector100pin: 'in-out',
            connector101pin: 'in-out',
            connector102pin: 'in-out',
            connector103pin: 'in-out',
            connector104pin: 'in-out',
            connector105pin: 'in-out',
            connector106pin: 'in-out',
            connector107pin: 'in-out'
        }
    })
    
}

main(input){
    
    var output = {
        connector76pin: '0',
            connector77pin: '1',
            connector78pin: '0',
            connector79pin: '1',
            connector80pin: '0',
            connector81pin: '1',
            connector82pin: '0',
            connector83pin: '1',
            connector84pin: '0',
            connector85pin: '1',
            connector86pin: '0',
            connector87pin: '1',
            connector88pin: '0',
            connector89pin: '1',
            connector90pin: '0',
            connector91pin: '1',
            connector92pin: '0',
            connector93pin: '1',
            connector94pin: '0',
            connector95pin: '1',
            connector96pin: '0',
            connector97pin: '1',
            connector98pin: '0',
            connector99pin: '1',
            connector100pin: '0',
            connector101pin: '1',
            connector102pin: '0',
            connector103pin: '1',
            connector104pin: '0',
            connector105pin: '1',
            connector106pin: '0',
            connector107pin: '1'
    }
    
    console.log('arduino leo')
    
    return output
}